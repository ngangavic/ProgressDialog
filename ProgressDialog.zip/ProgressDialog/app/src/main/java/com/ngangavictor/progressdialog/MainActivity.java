package com.ngangavictor.progressdialog;

import android.content.Intent;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    private TextView textView;
    private ProgressBar progressBar;
    CountDownTimer countDownTimer;
    public int timerCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.text);
        progressBar = findViewById(R.id.progressBar);
        Button button = findViewById(R.id.button);

        countDownTimer = new CountDownTimer(30000, 1000) {

            @Override
            public void onTick(long millisUntilFinished) {

                timerCount++;
                String time = String.valueOf(timerCount);
                progressBar.setProgress((int) (timerCount * 3.4));
                textView.setText("00." + time);
            }

            @Override
            public void onFinish() {
                progressBar.setVisibility(View.GONE);
                textView.setVisibility(View.GONE);
            }
        };

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                countDownTimer.start();
            }
        });
    }

    private void click(){

    }

}
